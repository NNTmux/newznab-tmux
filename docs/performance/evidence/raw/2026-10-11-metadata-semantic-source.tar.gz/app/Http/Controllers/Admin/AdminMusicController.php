<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\BasePageController;
use App\Services\GenreService;
use App\Services\MusicService;
use App\Services\ReleaseImageService;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class AdminMusicController extends BasePageController
{
    /**
     * Display a listing of music
     */
    public function index(Request $request): mixed
    {
        $meta_title = $title = 'Music List';

        // Get search parameter
        $search = $this->scalarInput($request, 'musicsearch');

        if (! empty($search)) {
            $musicList = getRange('musicinfo');
            $lastSearch = $search;
        } else {
            $musicList = getRange('musicinfo');
            $lastSearch = '';
        }

        return view('admin.music.index', compact('title', 'meta_title', 'musicList', 'lastSearch'));
    }

    /**
     * Show the form for editing music
     */
    public function edit(Request $request): mixed
    {
        $music = new MusicService;
        $gen = new GenreService;

        $meta_title = $title = 'Music Edit';

        // Set the current action
        $action = $this->formAction($request);

        if ($request->has('id')) {
            $id = (int) $request->input('id');
            $mus = $music->getMusicInfo($id);

            if (! $mus) {
                abort(404, 'Music not found');
            }

            switch ($action) {
                case 'submit':
                    $coverDirectory = storage_path('covers/music/');
                    $imageService = app(ReleaseImageService::class);

                    if ($request->hasFile('cover') && $request->file('cover')->isValid()) {
                        $imageService->saveUploadedImage((string) $id, $request->file('cover'), $coverDirectory);
                    }

                    $cover = (int) $imageService->imageExists($coverDirectory, (string) $id);
                    $salesrankInput = $request->input('salesrank');
                    $salesrank = (empty($salesrankInput) || ! ctype_digit((string) $salesrankInput)) ? null : (int) $salesrankInput;
                    $releasedateInput = $request->input('releasedate');
                    $releasedate = (empty($releasedateInput) || ! strtotime($releasedateInput))
                        ? $mus->releasedate
                        : Carbon::parse($releasedateInput)->toDateTimeString();

                    $genreInput = $request->input('genre');
                    $genreId = ! empty($genreInput) ? (int) $genreInput : null;

                    $music->update(
                        $id,
                        (string) $request->input('title', ''),
                        $request->input('asin'),
                        $request->input('url'),
                        $salesrank,
                        $request->input('artist'),
                        $request->input('publisher'),
                        $releasedate,
                        $request->input('year'),
                        $request->input('tracks'),
                        $cover,
                        $genreId
                    );

                    return redirect()->route('admin.music-list')->with('success', 'Music updated successfully');

                case 'view':
                default:
                    $genres = $gen->getGenres((string) GenreService::MUSIC_TYPE);

                    return view('admin.music.edit', compact('title', 'meta_title', 'mus', 'genres'));
            }
        }

        abort(404, 'Music ID required');
    }
}
