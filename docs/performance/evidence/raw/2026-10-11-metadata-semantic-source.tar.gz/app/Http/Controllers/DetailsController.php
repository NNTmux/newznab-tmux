<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Country;
use App\Models\DnzbFailure;
use App\Models\Predb;
use App\Models\Release;
use App\Models\ReleaseComment;
use App\Models\ReleaseRegex;
use App\Models\ReleaseReport;
use App\Models\Video;
use App\Services\AnidbService;
use App\Services\BookService;
use App\Services\Configuration\ConfigurationProvider;
use App\Services\ConsoleService;
use App\Services\GamesService;
use App\Services\MovieService;
use App\Services\MusicService;
use App\Services\PopulateAniListService;
use App\Services\ReleaseExtraService;
use App\Services\Releases\ReleaseSearchService;
use Illuminate\Http\Request;

class DetailsController extends BasePageController
{
    private ReleaseSearchService $releaseSearchService;

    private MovieService $movieService;

    private ReleaseExtraService $releaseExtraService;

    public function __construct(
        ReleaseSearchService $releaseSearchService,
        MovieService $movieService,
        ReleaseExtraService $releaseExtraService
    ) {
        parent::__construct();
        $this->releaseSearchService = $releaseSearchService;
        $this->movieService = $movieService;
        $this->releaseExtraService = $releaseExtraService;
    }

    public function show(Request $request, string $guid): mixed
    {
        $data = Release::getByGuid($guid);
        $releaseRegex = '';
        if (! empty($data)) {
            $releaseRegex = ReleaseRegex::query()->where('releases_id', '=', $data['id'])->first();
        }

        if (! $data) {
            return redirect()->back();
        }

        if ($this->isPostBack($request)) {
            ReleaseComment::addComment((int) $data['id'], (string) $request->input('txtAddComment'), (int) $this->userdata->id, $request->ip());

            return redirect()->route('details', ['guid' => $guid])->with('success', 'Comment posted successfully!');
        }

        $reVideo = $this->releaseExtraService->getVideo($data['id']);
        $reAudio = $this->releaseExtraService->getAudio($data['id']);
        $reSubs = $this->releaseExtraService->getSubs($data['id']);
        $comments = ReleaseComment::getComments($data['id']);
        $similars = $this->releaseSearchService->searchSimilar($data['id'], $data['searchname'], (array) $this->userdata->categoryexclusions);
        $failed = DnzbFailure::getFailedCount($data['id']);
        $reportData = ReleaseReport::query()
            ->with('responder')
            ->where('releases_id', $data['id'])
            ->whereIn('status', ['pending', 'reviewed', 'resolved'])
            ->get();
        $reportCount = $reportData->count();
        $reportReasons = ReleaseReport::reasonKeysToLabels($reportData->pluck('reason')->unique()->implode(', '));
        $originalReportData = ReleaseReport::query()
            ->where('releases_id', $data['id'])
            ->orderByDesc('created_at')
            ->get();
        $totalReportCount = $originalReportData->count();
        $allReportReasons = ReleaseReport::reasonKeysToLabels($originalReportData->pluck('reason')->unique()->implode(', '));
        $publicReportResponses = ReleaseReport::query()
            ->with('responder')
            ->where('releases_id', $data['id'])
            ->where('response_is_public', true)
            ->whereNotNull('response')
            ->where('response', '!=', '')
            ->orderByDesc('responded_at')
            ->get();
        $showInfo = '';
        if ($data['videos_id'] > 0) {
            $showInfo = Video::getByVideoID($data['videos_id']);
        }

        $mov = '';
        if (imdb_id_is_valid($data['imdbid'])) {
            $mov = $this->movieService->getMovieInfo($data['imdbid']);
            if (! empty($mov['title'])) {
                $mov['title'] = str_replace(['/', '\\'], '', $mov['title']);
                if (! empty($mov['actors'])) {
                    $mov['actors'] = makeFieldLinks($mov, 'actors', 'movies');
                }
                if (! empty($mov['genre'])) {
                    $mov['genre'] = makeFieldLinks($mov, 'genre', 'movies');
                }
                if (! empty($mov['director'])) {
                    $mov['director'] = makeFieldLinks($mov, 'director', 'movies');
                }
                if (app(ConfigurationProvider::class)->site()->trailersDisplay) {
                    $trailer = empty($mov['trailer']) ? $this->movieService->getTrailer($data['imdbid']) : $mov['trailer'];
                    if ($trailer) {
                        $mov['trailer'] = sprintf('<iframe width="%d" height="%d" src="%s"></iframe>', app(ConfigurationProvider::class)->site()->trailerWidth, app(ConfigurationProvider::class)->site()->trailerHeight, e($trailer));
                    }
                }
            }
        }

        $game = '';
        if ((int) $data['gamesinfo_id'] > 0) {
            $game = (new GamesService)->getGamesInfoById($data['gamesinfo_id']);
        }

        $mus = '';
        if ((int) $data['musicinfo_id'] > 0) {
            $mus = (new MusicService)->getMusicInfo($data['musicinfo_id']);
        }

        $book = '';
        if ((int) $data['bookinfo_id'] > 0) {
            $book = (new BookService)->getBookInfo($data['bookinfo_id']);
        }

        $con = '';
        if ((int) $data['consoleinfo_id'] > 0) {
            $con = (new ConsoleService)->getConsoleInfo($data['consoleinfo_id']);
        }

        $AniDBAPIArray = '';
        if ($data['anidbid'] > 0) {
            $AniDBAPIArray = (new AnidbService)->getAnimeInfo($data['anidbid']);

            // If we have anilist_id but missing details, fetch from AniList
            if ($AniDBAPIArray && ! empty($AniDBAPIArray->anilist_id)) {
                $anilistId = $AniDBAPIArray->anilist_id;
                if (empty($AniDBAPIArray->country) && empty($AniDBAPIArray->media_type)) {
                    // Fetch fresh data from AniList if country/media_type is missing
                    try {
                        $palist = new PopulateAniListService;
                        $palist->populateTable('info', $anilistId);
                        // Refresh the data
                        $AniDBAPIArray = (new AnidbService)->getAnimeInfo($data['anidbid']);
                    } catch (\Exception $e) {
                        // Silently fail, use existing data
                    }
                }
            }
        }

        $pre = Predb::getForRelease($data['predb_id']);

        // Resolve AniDB country code to a Country model/name here so the view stays query-free
        $anidbCountryCode = null;
        if (is_object($AniDBAPIArray)) {
            $anidbCountryCode = $AniDBAPIArray->country ?? null;
        } elseif (is_array($AniDBAPIArray)) {
            $anidbCountryCode = $AniDBAPIArray['country'] ?? null;
        }
        $anidbCountryModel = null;
        $anidbCountryName = null;
        if (! empty($anidbCountryCode)) {
            $anidbCountryModel = Country::query()->find($anidbCountryCode);
            $anidbCountryName = $anidbCountryModel->name ?? $anidbCountryCode;
        }

        $this->viewData = array_merge($this->viewData, [
            'release' => $data,
            'reVideo' => $reVideo,
            'reAudio' => $reAudio,
            'reSubs' => $reSubs,
            'show' => $showInfo,
            'movie' => $mov,
            'anidb' => $AniDBAPIArray,
            'anidbCountryModel' => $anidbCountryModel,
            'anidbCountryName' => $anidbCountryName,
            'music' => $mus,
            'con' => $con,
            'game' => $game,
            'book' => $book,
            'predb' => $pre,
            'comments' => $comments,
            'searchname' => getSimilarName($data['searchname']),
            'similars' => $similars !== false ? $similars : [],
            'privateprofiles' => config('nntmux_settings.private_profiles'),
            'failed' => $failed,
            'reportCount' => $reportCount,
            'reportReasons' => $reportReasons,
            'originalReportData' => $originalReportData,
            'totalReportCount' => $totalReportCount,
            'allReportReasons' => $allReportReasons,
            'publicReportResponses' => $publicReportResponses,
            'regex' => $releaseRegex,
            'meta_title' => 'View NZB',
            'meta_keywords' => 'view,nzb,description,details',
            'meta_description' => 'View NZB for '.$data['searchname'],
        ]);

        return view('details.index', $this->viewData);
    }
}
