<?php

declare(strict_types=1);

namespace App\Providers;

use App\Models\User;
use App\Observers\UserActivityObserver;
use App\Observers\UserApiCacheObserver;
use App\Observers\UserServiceObserver;
use Illuminate\Support\ServiceProvider;

class UserServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        User::observe(UserServiceObserver::class);
        User::observe(UserActivityObserver::class);
        User::observe(UserApiCacheObserver::class);
    }
}
