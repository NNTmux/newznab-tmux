<?php

declare(strict_types=1);

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\UserMovie.
 *
 * @property int $id
 * @property int $users_id
 * @property string|null $imdbid
 * @property string|null $categories List of categories for user movies
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 *
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\UserMovie whereCategories($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\UserMovie whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\UserMovie whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\UserMovie whereImdbid($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\UserMovie whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\UserMovie whereUsersId($value)
 *
 * @mixin \Eloquent
 *
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\UserMovie newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\UserMovie newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\UserMovie query()
 */
class UserMovie extends Model
{
    /**
     * @var array<string>
     */
    protected $guarded = [];

    protected $dateFormat = false;

    /**
     * @param  array<int|string, mixed>  $catID
     * @return int|Builder
     */
    public static function addMovie(mixed $uid, mixed $imdbid, array $catID = []) // @phpstan-ignore missingType.generics
    {
        return self::query()
            ->insertGetId(
                [
                    'users_id' => $uid,
                    'imdbid' => $imdbid,
                    'categories' => ! empty($catID) ? implode('|', $catID) : 'NULL',
                    'created_at' => now(),
                ]
            );
    }

    /**
     * @return array<string, mixed>
     */
    public static function getMovies(mixed $uid): array
    {
        return self::query()
            ->where('users_id', $uid)
            ->leftJoin('movieinfo as mi', 'mi.imdbid', '=', 'user_movies.imdbid')
            ->orderBy('mi.title')
            ->get(['user_movies.*', 'mi.year', 'mi.plot', 'mi.cover', 'mi.title'])
            ->toArray();
    }

    /**
     * @return mixed
     */
    public static function delMovie(mixed $uid, mixed $imdbid)
    {
        return self::query()->where(['users_id' => $uid, 'imdbid' => $imdbid])->delete();
    }

    /**
     * @return array<string, mixed>
     */
    public static function getMovie(mixed $uid, mixed $imdbid): array
    {
        $result = self::query()
            ->where(['user_movies.users_id' => $uid, 'user_movies.imdbid' => $imdbid])
            ->leftJoin('movieinfo as mi', 'mi.imdbid', '=', 'user_movies.imdbid')
            ->first(['user_movies.*', 'mi.title']);

        return $result ? $result->toArray() : [];
    }

    public static function delMovieForUser(mixed $uid): void
    {
        self::query()->where('users_id', $uid)->delete();
    }

    /**
     * @param  array<int|string, mixed>  $catID
     */
    public static function updateMovie(mixed $uid, mixed $imdbid, array $catID = []): void
    {
        self::query()
            ->where(['users_id' => $uid, 'imdbid' => $imdbid])
            ->update(['categories' => ! empty($catID) ? implode('|', $catID) : 'NULL']);
    }
}
