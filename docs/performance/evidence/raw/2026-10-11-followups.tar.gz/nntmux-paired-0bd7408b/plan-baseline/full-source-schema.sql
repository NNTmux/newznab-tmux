CREATE TABLE `usenet_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `backfill_target` int(11) NOT NULL DEFAULT 1,
  `first_record` bigint(20) unsigned NOT NULL DEFAULT 0,
  `first_record_postdate` datetime DEFAULT NULL,
  `last_record` bigint(20) unsigned NOT NULL DEFAULT 0,
  `last_record_postdate` datetime DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `minfilestoformrelease` int(11) DEFAULT NULL,
  `minsizetoformrelease` bigint(20) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `backfill` tinyint(1) NOT NULL DEFAULT 0,
  `description` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_groups_name` (`name`),
  KEY `active` (`active`),
  KEY `ix_usenet_groups_active_name_admin` (`active`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `collection_regexes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_regex` varchar(255) NOT NULL DEFAULT '' COMMENT 'This is a regex to match against usenet groups',
  `regex` varchar(5000) NOT NULL DEFAULT '' COMMENT 'Regex used for collection grouping',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=ON 0=OFF',
  `description` varchar(1000) NOT NULL COMMENT 'Optional extra details on this regex',
  `ordinal` int(11) NOT NULL DEFAULT 0 COMMENT 'Order to run the regex in',
  PRIMARY KEY (`id`),
  KEY `ix_collection_regexes_group_regex` (`group_regex`),
  KEY `ix_collection_regexes_status` (`status`),
  KEY `ix_collection_regexes_ordinal` (`ordinal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `collections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `fromname` varchar(255) NOT NULL DEFAULT '',
  `date` datetime DEFAULT NULL,
  `xref` varchar(2000) NOT NULL DEFAULT '',
  `totalfiles` int(10) unsigned NOT NULL DEFAULT 0,
  `groups_id` int(10) unsigned NOT NULL DEFAULT 0,
  `collectionhash` binary(20) NOT NULL,
  `collection_regexes_id` int(11) NOT NULL DEFAULT 0 COMMENT 'FK to collection_regexes.id',
  `dateadded` datetime DEFAULT NULL,
  `last_seen_at` datetime DEFAULT NULL,
  `added` timestamp NOT NULL DEFAULT current_timestamp(),
  `filecheck` tinyint(1) NOT NULL DEFAULT 0,
  `filesize` bigint(20) unsigned NOT NULL DEFAULT 0,
  `releases_id` int(11) DEFAULT NULL,
  `release_creation_claimed_at` timestamp NULL DEFAULT NULL,
  `release_creation_claim_token` varchar(64) DEFAULT NULL,
  `release_creation_failures` smallint(5) unsigned NOT NULL DEFAULT 0,
  `release_creation_failed_at` timestamp NULL DEFAULT NULL,
  `release_creation_error` varchar(512) DEFAULT NULL,
  `noise` char(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_collection_collectionhash` (`collectionhash`),
  KEY `fromname` (`fromname`),
  KEY `date` (`date`),
  KEY `groups_id` (`groups_id`),
  KEY `ix_collection_dateadded` (`dateadded`),
  KEY `ix_collection_filecheck` (`filecheck`),
  KEY `ix_collection_releaseid` (`releases_id`),
  KEY `collections_groups_added_idx` (`groups_id`,`added`),
  KEY `collections_dateadded_idx` (`dateadded`),
  KEY `ix_collections_filecheck_filesize_groups` (`filecheck`,`filesize`,`groups_id`),
  KEY `ix_collections_release_creation_claim_queue` (`filecheck`,`groups_id`,`release_creation_claimed_at`,`id`),
  KEY `ix_collections_group_filecheck_seen_id` (`groups_id`,`filecheck`,`last_seen_at`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `collection_groups` (
  `collections_id` int(10) unsigned NOT NULL,
  `group_name` varchar(255) NOT NULL,
  PRIMARY KEY (`collections_id`,`group_name`),
  CONSTRAINT `fk_collection_groups_collection` FOREIGN KEY (`collections_id`) REFERENCES `collections` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

CREATE TABLE `binaries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `binaryhash` binary(16) NOT NULL,
  `name` varchar(1000) NOT NULL DEFAULT '',
  `collections_id` int(10) unsigned NOT NULL DEFAULT 0,
  `filenumber` int(10) unsigned NOT NULL DEFAULT 0,
  `totalparts` int(10) unsigned NOT NULL DEFAULT 0,
  `currentparts` int(10) unsigned NOT NULL DEFAULT 0,
  `partcheck` tinyint(1) NOT NULL DEFAULT 0,
  `partsize` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_binaries_collection_hash` (`collections_id`,`binaryhash`),
  KEY `ix_binaries_collection` (`collections_id`),
  KEY `ix_binaries_partcheck` (`partcheck`),
  KEY `ix_binaries_collection_filenumber` (`collections_id`,`filenumber`),
  CONSTRAINT `FK_Collections` FOREIGN KEY (`collections_id`) REFERENCES `collections` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `parts` (
  `binaries_id` bigint(20) unsigned NOT NULL,
  `messageid` varchar(255) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `number` bigint(20) unsigned NOT NULL DEFAULT 0,
  `partnumber` int(10) unsigned NOT NULL DEFAULT 0,
  `size` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`binaries_id`,`partnumber`),
  KEY `ix_parts_number` (`number`),
  CONSTRAINT `FK_binaries` FOREIGN KEY (`binaries_id`) REFERENCES `binaries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
