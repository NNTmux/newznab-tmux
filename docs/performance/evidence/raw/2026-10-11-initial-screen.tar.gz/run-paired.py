#!<machine-path> python3
"""Private disposable paired runner. Dry-run by default; no production endpoints."""
import argparse,hashlib,json,pathlib,shutil,subprocess,time,uuid

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def call(args,timeout=20):
    r=subprocess.run(args,capture_output=True,text=True,timeout=timeout)
    if r.returncode:raise RuntimeError('Command failed: '+args[0]+'; '+r.stderr[-800:])
    return r.stdout

def digest_map(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def source_manifest(root):
    return {str(f.relative_to(root)):sha(f) for f in root.rglob('*') if f.is_file() and 'vendor' not in f.relative_to(root).parts}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--handoff',required=True);ap.add_argument('--execute',action='store_true');args=ap.parse_args()
    root=pathlib.Path(__file__).resolve().parent;h=json.loads(pathlib.Path(args.handoff).read_text());order=json.loads((root/'paired-order.json').read_text());jobs=order['jobs']
    if not args.execute:print(json.dumps({'status':'offline_only','observations':len(jobs),'required_gates':['green_verified','formatted_source_frozen','runtime_released']}));return
    for gate in ['green_verified','formatted_source_frozen','runtime_released']:
        if h.get(gate) is not True:raise RuntimeError('Handoff gate missing: '+gate)
    for file,key in [('run-paired.py','runner_sha256'),('paired-order.json','order_sha256')]:
        if sha(root/file)!=h[key]:raise RuntimeError('Protocol/order identity mismatch')
    expected={(r,s,w,c) for r in [0,1] for s in [2,32] for w in [4,6,12] for c in [100,500]};pairs={}
    if len(jobs)!=48 or len({j['identity'] for j in jobs})!=48:raise RuntimeError('Matrix cardinality mismatch')
    for j in jobs:pairs.setdefault(j['pair_id'],[]).append(j)
    if len(pairs)!=24:raise RuntimeError('Pair cardinality mismatch')
    configurations=set()
    for pair in pairs.values():
        if len(pair)!=2 or {j['variant'] for j in pair}!={'baseline','candidate'}:raise RuntimeError('Invalid source pair')
        keys={(j['repeat'],j['collections'],j['workers'],j['header_chunk']) for j in pair}
        if len(keys)!=1:raise RuntimeError('Pair configuration mismatch')
        configurations.update(keys)
    if configurations!=expected:raise RuntimeError('Matrix coverage mismatch')
    baseline=root/h['baseline_bundle'];candidate=root/h['candidate_bundle'];vendor=root/h['vendor_bundle'];schema=root/h['schema_file'];full_schema=root/h['full_source_schema_file']
    (baseline/'vendor').mkdir(exist_ok=True);(candidate/'vendor').mkdir(exist_ok=True)
    a=source_manifest(baseline);b=source_manifest(candidate);allowed='app/Services/Binaries/CollectionHandler.php'
    if set(a)!=set(b) or [k for k in a if a[k]!=b[k]]!=[allowed]:raise RuntimeError('Source difference scope is not CollectionHandler-only')
    for v,m in [('baseline',a),('candidate',b)]:
        if digest_map(m)!=h[v+'_source_manifest_sha256']:raise RuntimeError('Whole source manifest mismatch')
        if m[allowed]!=h[v+'_collection_sha256']:raise RuntimeError('Source hash is not frozen')
    if sha(schema)!=h['schema_sha256'] or sha(root/'bench-paired-case.php')!=h['protocol_sha256']:raise RuntimeError('Schema/protocol hash mismatch')
    if sha(full_schema)!=h['full_source_schema_sha256']:raise RuntimeError('Plan-gate source schema mismatch')
    if not vendor.is_dir():raise RuntimeError('Missing common vendor bundle')
    vendor_manifest={str(f.relative_to(vendor)):sha(f) for f in vendor.rglob('*') if f.is_file()}
    vendor_hash=hashlib.sha256(json.dumps(vendor_manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    if vendor_hash!=h['vendor_manifest_sha256']:raise RuntimeError('Vendor identity mismatch')
    php_image=h['php_runtime_image'];db_image=h['db_image']
    if not all(x.startswith('sha256:') for x in [php_image,db_image]):raise RuntimeError('Runtime images must be immutable cached IDs')
    for image in [php_image,db_image]:
        if call(['docker','image','inspect',image,'--format','{{.Id}}']).strip()!=image:raise RuntimeError('Runtime identity mismatch')
    name='nntmux-paired-'+uuid.uuid4().hex[:8];out=root/name;out.mkdir();report={'start_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'handoff':{k:h[k] for k in ['schema_sha256','protocol_sha256','baseline_collection_sha256','candidate_collection_sha256','php_runtime_image','db_image','vendor_manifest_sha256']},'storage':'tmpfs historical matched profile','order_seed':order['order_seed'],'screen_only':True,'observations':[]};start=time.monotonic();(out/'baseline-source-manifest.json').write_text(json.dumps(a,sort_keys=True,indent=2));(out/'candidate-source-manifest.json').write_text(json.dumps(b,sort_keys=True,indent=2));(out/'paired-order.json').write_text(json.dumps(order,indent=2))
    db=name+'-db';network=name;apps=[];semantic_verified=set()
    try:
        call(['docker','network','create','--internal',network])
        call(['docker','run','-d','--name',db,'--network',network,'--network-alias','bench-db','--cpus','0.75','--memory','512m','--tmpfs','<machine-path>','-e','MARIADB_ALLOW_EMPTY_ROOT_PASSWORD=1','-e','MARIADB_ROOT_HOST=%','-e','MARIADB_DATABASE=bench',db_image,'--innodb-buffer-pool-size=128M','--innodb-log-file-size=64M','--innodb-flush-log-at-trx-commit=2','--innodb-autoinc-lock-mode=2','--transaction-isolation=READ-COMMITTED','--skip-log-bin','--max-connections=40'])
        ready=False
        for _ in range(40):
            r=subprocess.run(['docker','exec',db,'mariadb','--protocol=tcp','-h127.0.0.1','-uroot','-N','-e','SELECT 1 FROM information_schema.SCHEMATA WHERE SCHEMA_NAME="bench"'],capture_output=True,timeout=5)
            if r.returncode==0 and r.stdout.strip()==b'1':ready=True;break
            time.sleep(.25)
        if not ready:raise RuntimeError('Disposable database readiness failed')
        pid=int(call(['docker','inspect',db,'--format','{{.State.Pid}}']).strip());cg=None
        for line in pathlib.Path('/proc/'+str(pid)+'/cgroup').read_text().splitlines():
            if line.startswith('0::'):cg=pathlib.Path('<machine-path>')/line[3:].lstrip('/')/'cpu.stat'
        if cg is None or not cg.is_file():raise RuntimeError('DB cgroup v2 counter unavailable; revise declared instrumentation before running')
        # Mandatory actual-handler/source-schema plan gate, before timed observations.
        report['plan_gates']={}
        for variant,bundle,m in [('baseline',baseline,a),('candidate',candidate,b)]:
            plan_dir=out/('plan-'+variant);plan_dir.mkdir();shutil.copyfile(full_schema,plan_dir/'full-source-schema.sql');shutil.copyfile(root/'bench-paired-case.php',plan_dir/'bench.php')
            selected=dict(next(j for j in jobs if j['variant']==variant));selected['source_hashes']={key:m['app/Services/Binaries/'+key+'.php'] for key in ['HeaderStorageService','CollectionHandler','BinaryHandler','PartHandler']};selected['handler_sha256']=m[allowed]
            app=name+'-plan-'+variant;apps.append(app)
            cmd=['docker','run','--name',app,'--network',network,'--cpus','0.5','--memory','512m','--user','0','--mount','type=bind,src='+str(bundle)+',dst=/app,readonly','--mount','type=bind,src='+str(vendor)+',dst=<machine-path>','--mount','type=bind,src='+str(plan_dir)+',dst=/bench','--workdir','/app','--env','BENCH_PLAN_GATE=1','--env','BENCH_PLAN_SCHEMA_SHA='+h['full_source_schema_sha256'],'--env','BENCH_CASE_JSON='+json.dumps(selected,separators=(',',':')),'--entrypoint','php',php_image,'-d','memory_limit=192M','/bench/bench.php']
            try:
                with (plan_dir/'stdout.log').open('w') as stdout,(plan_dir/'stderr.log').open('w') as stderr:r=subprocess.run(cmd,stdout=stdout,stderr=stderr,text=True,timeout=120)
            finally:
                cleanup=subprocess.run(['docker','rm','-f',app],capture_output=True,timeout=15)
                if cleanup.returncode==0:apps.remove(app)
            if r.returncode!=0 or not (plan_dir/'report.json').is_file():raise RuntimeError('Plan-gate execution failed: '+variant)
            plan_report=json.loads((plan_dir/'report.json').read_text());gate=plan_report.get('plan_gate',{})
            expected_plans={(state,shape,n) for state in ['no_explicit_analyze','analyzed'] for shape in ['dense','sparse'] for n in [1,2,32,500]}
            if gate.get('passed') is not True or {(x['statistics'],x['shape'],x['wanted_count']) for x in gate.get('cases',[])}!=expected_plans or len(gate.get('cases',[]))!=16:raise RuntimeError('Plan-gate coverage incomplete')
            if variant=='candidate' and not all(x['candidate_primary_bounded'] for x in gate['cases']):raise RuntimeError('Candidate plan gate failed')
            report['plan_gates'][variant]=plan_report;(out/'report.json').write_text(json.dumps(report,indent=2))
        if report['plan_gates']['baseline']['plan_gate']['normalized_effective_ddl']!=report['plan_gates']['candidate']['plan_gate']['normalized_effective_ddl']:raise RuntimeError('Effective schema differs between source variants')
        for j in jobs:
            if time.monotonic()-start>1500:raise RuntimeError('Matrix time bound exceeded')
            if source_manifest(baseline)!=a or source_manifest(candidate)!=b:raise RuntimeError('Source changed during matrix')
            case=out/j['identity'];case.mkdir();shutil.copyfile(schema,case/'schema.sql');shutil.copyfile(root/'bench-paired-case.php',case/'bench.php')
            selected=dict(j);m=a if j['variant']=='baseline' else b;selected['source_hashes']={key:m['app/Services/Binaries/'+key+'.php'] for key in ['HeaderStorageService','CollectionHandler','BinaryHandler','PartHandler']};selected['handler_sha256']=m[allowed]
            app=name+'-'+str(len(report['observations']));apps.append(app);bundle=baseline if j['variant']=='baseline' else candidate
            cmd=['docker','run','--name',app,'--network',network,'--cpus','0.5','--memory','512m','--user','0','--mount','type=bind,src='+str(bundle)+',dst=/app,readonly','--mount','type=bind,src='+str(vendor)+',dst=<machine-path>','--mount','type=bind,src='+str(case)+',dst=/bench','--mount','type=bind,src='+str(cg)+',dst=/bench-db-cpu.stat,readonly','--workdir','/app','--env','BENCH_SEMANTICS='+('0' if j['variant'] in semantic_verified else '1'),'--env','BENCH_CASE_JSON='+json.dumps(selected,separators=(',',':')),'--entrypoint','php',php_image,'-d','memory_limit=192M','/bench/bench.php']
            try:
                with (case/'stdout.log').open('w') as stdout,(case/'stderr.log').open('w') as stderr:r=subprocess.run(cmd,stdout=stdout,stderr=stderr,text=True,timeout=120)
            except subprocess.TimeoutExpired:
                (case/'incomplete-orchestrator.json').write_text(json.dumps({'classification':'harness_invalid','reason':'observation_timeout','selection':selected}));raise RuntimeError('Observation timeout: '+j['identity'])
            finally:
                try:
                    cleanup=subprocess.run(['docker','rm','-f',app],capture_output=True,timeout=15)
                    if cleanup.returncode==0:apps.remove(app)
                except subprocess.TimeoutExpired:raise RuntimeError('Application cleanup timeout: '+j['identity'])
            if r.returncode!=0 or not (case/'report.json').is_file():raise RuntimeError('Observation execution failed: '+j['identity'])
            observation=json.loads((case/'report.json').read_text())
            if observation.get('execution_complete') is not True or observation.get('harness_valid') is not True or len(observation.get('cases',[]))!=1:raise RuntimeError('Observation incomplete: '+j['identity'])
            if j['variant'] not in semantic_verified:
                gates=observation.get('semantic_gates',{})
                if set(gates)!={'real_missing_parent','atomic_rollback_replay'} or not all(g.get('passed') is True for g in gates.values()):raise RuntimeError('Semantic gates incomplete')
                semantic_verified.add(j['variant'])
            c=observation['cases'][0]
            if c['child_errors'] or not all(c['child_normal_exits']) or any(c['child_exit_codes']) or any(c['child_signals']):raise RuntimeError('Child process/harness failure: '+j['identity'])
            if j['variant']=='baseline' and not c['valid_initial_storage_run']:
                reasons=c['rollback_records']
                if not reasons or not all(x.get('reason')=='Lock retries exhausted' and x.get('driver_code') in [1020,1205,1213] for x in reasons):raise RuntimeError('Unclassified baseline storage failure: '+j['identity'])
            report['observations'].append({'selection':selected,'report':observation});(out/'report.json').write_text(json.dumps(report,indent=2))
            print(json.dumps({'observation':j['identity'],'valid_initial':c['valid_initial_storage_run'],'successful_new_parts':c['actual_new_unique_parts'],'wall':c['seconds']}),flush=True)
            if j['variant']=='candidate' and c['valid_initial_storage_run'] is not True:raise RuntimeError('Candidate initial correctness gate failed')
        report['execution_complete']=True
    except Exception as e:report['execution_complete']=False;report['error']=str(e);raise
    finally:
        cleanup={}
        for label,args in [(app,['docker','rm','-f',app]) for app in apps]+[('db',['docker','rm','-f',db]),('network',['docker','network','rm',network])]:
            try:r=subprocess.run(args,capture_output=True,timeout=15);cleanup[label]=r.returncode
            except Exception as e:cleanup[label]={'error_type':type(e).__name__}
        report['cleanup_exit']=cleanup;report['end_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());(out/'report.json').write_text(json.dumps(report,indent=2))


if __name__=='__main__':main()
