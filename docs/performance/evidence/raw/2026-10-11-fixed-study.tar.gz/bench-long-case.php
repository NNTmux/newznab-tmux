<?php
declare(strict_types=1);
require '<machine-path>';
use App\Services\Binaries\{BinariesConfig,CollectionHandler,HeaderStorageService};
use App\Services\CollectionsCleaningService;
use App\Services\Tmux\CollectionDowntimeCompensator;
use Illuminate\Foundation\Application;
use Illuminate\Config\Repository;
use Illuminate\Database\Capsule\Manager as Capsule;
use Illuminate\Events\Dispatcher;
use Illuminate\Support\Facades\{DB,Facade};
use Illuminate\Support\DateFactory;
use Psr\Log\NullLogger;
final class BenchLogger extends Psr\Log\AbstractLogger {
    public array $issues=[];
    public array $driverErrors=[];
    public function log($level,string|Stringable $message,array $context=[]): void {
        if(preg_match('/\b(1452|1213|1205|1020)\b/',(string)$message,$match)===1){$this->driverErrors[]=(int)$match[1];}
        if($message==='Binary header storage chunk rolled back' && count($this->issues)<100){$this->issues[]=array_intersect_key($context,array_flip(['reason','attempts','driver_code','constraint','article_count']));}
    }
}
function connectApp(): void {
    if(preg_match('/^bench_[a-f0-9]{12}$/',(string)getenv('BENCH_DB_DATABASE'))!==1 || preg_match('/^bench_ingestion_[a-f0-9]{16}$/',(string)getenv('BENCH_EPOCH_MARKER'))!==1){throw new RuntimeException('Invalid isolated fixture database');}
    $app=new Application('/app');
    $app->instance('config',new Repository(['app'=>['debug'=>true,'timezone'=>'UTC']]));
    $app->instance('log',new BenchLogger);
    $app->instance('date',new DateFactory);
    $capsule=new Capsule($app);
    $capsule->addConnection(['driver'=>'mysql','host'=>'bench-db','port'=>3306,'url'=>null,'unix_socket'=>'','database'=>(string)getenv('BENCH_DB_DATABASE'),'username'=>'root','password'=>'','charset'=>'utf8mb4','collation'=>'utf8mb4_unicode_ci','options'=>[PDO::ATTR_EMULATE_PREPARES=>false]]);
    $capsule->setEventDispatcher(new Dispatcher($app));
    $capsule->setAsGlobal();$capsule->bootEloquent();
    $app->instance('db',$capsule->getDatabaseManager());
    $app->instance(CollectionDowntimeCompensator::class,new CollectionDowntimeCompensator('/tmp/'.(string)getenv('BENCH_EPOCH_MARKER')));
    Facade::clearResolvedInstances();Facade::setFacadeApplication($app);
    DB::statement('SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED');
}
function service(int $chunk): HeaderStorageService {
    $cleaner=new class extends CollectionsCleaningService {
        public function collectionsCleaner(string $subject,string $groupName=''): array {
            preg_match('/Bench\.Collection\.(\d+)/',$subject,$m);
            return ['id'=>0,'name'=>'Bench.Collection.'.$m[1]];
        }
    };
    return new HeaderStorageService(new CollectionHandler($cleaner,sqlChunkSize:500),config:new BinariesConfig(headerChunkSize:$chunk,sqlChunkSize:500));
}
function resetSchema(): void {
    DB::statement('SET FOREIGN_KEY_CHECKS=0');
    foreach(['parts','binaries','collection_groups','collections','collection_regexes','usenet_groups'] as $t){DB::statement('DROP TABLE IF EXISTS '.$t);}
    DB::statement('SET FOREIGN_KEY_CHECKS=1');
    foreach(explode(';',file_get_contents('/bench/schema.sql')) as $sql){if(trim($sql)!==''){DB::statement($sql);}}
    DB::table('usenet_groups')->insert([['id'=>1,'name'=>'alt.binaries.bench.a'],['id'=>2,'name'=>'alt.binaries.bench.b']]);
}
function headers(int $collections): array {
    $rows=[];$perBinary=intdiv(10240,$collections*4);
    for($i=0;$i<10240;$i++){
        $c=$i%$collections;$f=intdiv($i,$collections)%4+1;$part=intdiv($i,$collections*4)+1;
        $name="Bench.Collection.{$c} [{$f}/4] file{$f}.bin";
        $rows[]=['Number'=>$i+100000,'Subject'=>"{$name} ({$part}/{$perBinary})",'From'=>'synthetic@example.test','Date'=>1791750000,'Bytes'=>1024+$i%127,'Message-ID'=>"<synthetic-{$i}@example.test>",'Xref'=>'news.example alt.binaries.bench.a:'.($i+100000).' alt.binaries.bench.b:'.($i+200000),'matches'=>[0=>$name,1=>$name,2=>$part,3=>$perBinary]];
    }
    return $rows;
}
function counters(): array {
    $s=[];foreach(DB::select("SHOW GLOBAL STATUS WHERE Variable_name IN ('Innodb_row_lock_time','Innodb_row_lock_waits','Innodb_deadlocks','Innodb_buffer_pool_reads','Innodb_buffer_pool_read_requests','Innodb_buffer_pool_wait_free')") as $r){$s[$r->Variable_name]=(int)$r->Value;}return $s;
}
function verify(array $canonical,int $collections): array {
    $actualParts=(int)DB::table('parts')->count();$expectedBytes=array_sum(array_column($canonical,'Bytes'));
    $binaryMismatch=(int)DB::selectOne('SELECT COUNT(*) AS n FROM binaries b LEFT JOIN (SELECT binaries_id,COUNT(*) AS n,SUM(size) AS bytes FROM parts GROUP BY binaries_id) p ON p.binaries_id=b.id WHERE b.currentparts<>COALESCE(p.n,0) OR b.partsize<>COALESCE(p.bytes,0) OR b.currentparts<>b.totalparts OR b.partcheck<>1')->n;
    $collectionMismatch=(int)DB::selectOne('SELECT COUNT(*) AS n FROM collections c LEFT JOIN (SELECT collections_id,SUM(partsize) AS bytes FROM binaries GROUP BY collections_id) b ON b.collections_id=c.id WHERE c.filesize<>COALESCE(b.bytes,0)')->n;
    $orphans=(int)DB::selectOne('SELECT COUNT(*) AS n FROM parts p LEFT JOIN binaries b ON b.id=p.binaries_id WHERE b.id IS NULL')->n;
    $result=['parts'=>$actualParts,'collections'=>(int)DB::table('collections')->count(),'binaries'=>(int)DB::table('binaries')->count(),'crosspost_links'=>(int)DB::table('collection_groups')->count(),'bytes'=>(int)DB::table('parts')->sum('size'),'binary_mismatches'=>$binaryMismatch,'collection_mismatches'=>$collectionMismatch,'orphans'=>$orphans];
    $result['readiness_mismatches']=(int)DB::table('collections')->where(function($q){$q->where('filecheck','<>',App\Enums\CollectionFileCheckStatus::Sized->value)->orWhere('totalfiles','<>',4);})->count();
    $result=[...$result,...verifyIdentity($collections)];
    $result['passed']=$result['identity_passed'] && $result['readiness_mismatches']===0 && $actualParts===10240 && $result['bytes']===$expectedBytes && $result['collections']===$collections && $result['binaries']===$collections*4 && $result['crosspost_links']===$collections*2 && $binaryMismatch===0 && $collectionMismatch===0 && $orphans===0;
    return $result;
}

function cpuSnapshot(): array {
    $out=[];
    foreach(['app'=>'<machine-path>','db'=>'/bench-db-cpu.stat'] as $service=>$path){
        $raw=is_readable($path)?file_get_contents($path):false;
        $values=[];
        if($raw!==false){foreach(explode("\n",trim($raw)) as $line){$items=preg_split('/\s+/',trim($line));if(count($items)===2 && ctype_digit($items[1])){$values[$items[0]]=(int)$items[1];}}}
        $maxPath=$service==='app'?'<machine-path>':'/bench-db-cpu.max';$setPath=$service==='app'?'<machine-path>':'/bench-db-cpuset';$out[$service]=['available'=>$raw!==false,'counters'=>$values,'cpu_max'=>is_readable($maxPath)?trim(file_get_contents($maxPath)):null,'cpuset_effective'=>is_readable($setPath)?trim(file_get_contents($setPath)):null];
    }
    return $out;
}
function verifyIdentity(int $collections): array {
    $bad=0;$seen=[];
    $rows=DB::select('SELECT p.number,p.messageid,p.partnumber,p.size,b.filenumber,c.collectionhash FROM parts p JOIN binaries b ON b.id=p.binaries_id JOIN collections c ON c.id=b.collections_id');
    foreach($rows as $row){
        if(preg_match('/^<synthetic-(\d+)@example\.test>$/',(string)$row->messageid,$m)!==1){$bad++;continue;}
        $i=(int)$m[1];$duplicate=isset($seen[$i]);$seen[$i]=true;
        if($i<0 || $i>=10240 || $duplicate || (int)$row->number!==100000+$i || (int)$row->size!==1024+$i%127 || (int)$row->partnumber!==intdiv($i,$collections*4)+1 || (int)$row->filenumber!==intdiv($i,$collections)%4+1 || (string)$row->collectionhash!==sha1('Bench.Collection.'.($i%$collections).'4',true)){$bad++;}
    }
    return ['identity_mismatches'=>$bad,'distinct_fixture_parts'=>count($seen),'identity_passed'=>$bad===0 && count($seen)===10240];
}


function miniHeaders(): array {
    $rows=array_slice(headers(2),0,16);
    foreach($rows as &$row){$row['matches'][3]=2;$row['Subject']=preg_replace('/\(\d+\/\d+\)$/','('.$row['matches'][2].'/2)',$row['Subject']);}unset($row);
    return $rows;
}
function miniState(array $headers): array {
    $expected=[];foreach($headers as $h){$expected[$h['Message-ID']]=['number'=>$h['Number'],'size'=>$h['Bytes'],'partnumber'=>$h['matches'][2]];}
    $rows=DB::table('parts')->get();$identity=true;$seen=[];
    foreach($rows as $r){$id=(string)$r->messageid;if(isset($seen[$id]) || !isset($expected[$id])){$identity=false;continue;}$seen[$id]=true;foreach($expected[$id] as $key=>$v){if((int)$r->$key!==(int)$v){$identity=false;}}}
    $binaryBad=(int)DB::selectOne('SELECT COUNT(*) n FROM binaries b LEFT JOIN (SELECT binaries_id,COUNT(*) n,SUM(size) bytes FROM parts GROUP BY binaries_id) p ON p.binaries_id=b.id WHERE b.currentparts<>COALESCE(p.n,0) OR b.partsize<>COALESCE(p.bytes,0) OR b.currentparts<>2 OR b.totalparts<>2 OR b.partcheck<>1')->n;
    $collectionBad=(int)DB::selectOne('SELECT COUNT(*) n FROM collections c LEFT JOIN (SELECT collections_id,SUM(partsize) bytes FROM binaries GROUP BY collections_id) b ON b.collections_id=c.id WHERE c.filesize<>COALESCE(b.bytes,0) OR c.filecheck<>3 OR c.totalfiles<>4')->n;
    $result=['parts'=>count($rows),'binaries'=>(int)DB::table('binaries')->count(),'collections'=>(int)DB::table('collections')->count(),'crosspost_links'=>(int)DB::table('collection_groups')->count(),'bytes'=>(int)DB::table('parts')->sum('size'),'identity_passed'=>$identity && count($seen)===count($expected),'binary_mismatches'=>$binaryBad,'collection_mismatches'=>$collectionBad];
    $result['passed']=$result['parts']===16 && $result['binaries']===8 && $result['collections']===2 && $result['crosspost_links']===4 && $result['bytes']===array_sum(array_column($headers,'Bytes')) && $result['identity_passed'] && $binaryBad===0 && $collectionBad===0;return $result;
}
function semanticGates(): array {
    resetSchema();$mini=miniHeaders();if(service(500)->store($mini,['id'=>1,'name'=>'alt.binaries.bench.a'])!==[] || !miniState($mini)['passed']){throw new RuntimeException('Semantic seed failed');}
    $oldId=(int)DB::table('collections')->orderBy('id')->value('id');$deleted=false;$upserts=0;
    DB::listen(function($q)use(&$deleted,&$upserts,$oldId){
        if(str_starts_with($q->sql,'INSERT INTO collections')){$upserts++;}
        if(!$deleted && str_starts_with($q->sql,'SELECT id, collectionhash FROM collections')){
            $deleted=true;$pdo=new PDO('mysql:host=bench-db;port=3306;dbname='.(string)getenv('BENCH_DB_DATABASE'),'root','',[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);$stmt=$pdo->prepare('DELETE FROM collections WHERE id=?');$stmt->execute([$oldId]);if($stmt->rowCount()!==1){throw new RuntimeException('Observer delete did not remove owned seed parent');}
        }
    });
    $failed=service(500)->store($mini,['id'=>2,'name'=>'alt.binaries.bench.b']);$state=miniState($mini);$codes=Facade::getFacadeApplication()->make('log')->driverErrors;
    $race=['observer_delete_committed'=>$deleted,'upsert_attempts'=>$upserts,'driver_errors'=>$codes,'failed_articles'=>$failed,'old_parent_absent'=>!DB::table('collections')->where('id',$oldId)->exists(),'state'=>$state];
    $race['passed']=$deleted && $upserts>=2 && in_array(1452,$codes,true) && $failed===[] && $race['old_parent_absent'] && $state['passed'];
    if(!$race['passed']){throw new RuntimeException('Real missing-parent semantic gate failed');}
    DB::disconnect();connectApp();resetSchema();$injected=false;
    DB::listen(function($q)use(&$injected){if(!$injected && str_starts_with($q->sql,'INSERT IGNORE INTO parts')){$injected=true;throw new RuntimeException('Fixture nonretryable failure after real parts write');}});
    $rolledFailed=service(500)->store($mini,['id'=>1,'name'=>'alt.binaries.bench.a']);$empty=DB::table('parts')->count()===0 && DB::table('binaries')->count()===0 && DB::table('collections')->count()===0 && DB::table('collection_groups')->count()===0;$expectedNumbers=array_column($mini,'Number');sort($rolledFailed);sort($expectedNumbers);
    $rollback=['failure_injected'=>$injected,'all_rows_rolled_back'=>$empty,'failed_articles_match_chunk'=>$rolledFailed===$expectedNumbers];
    DB::disconnect();connectApp();$replayFailed=service(500)->store($mini,['id'=>1,'name'=>'alt.binaries.bench.a']);$rollback['replay_state']=miniState($mini);$rollback['passed']=$injected && $empty && $rollback['failed_articles_match_chunk'] && $replayFailed===[] && $rollback['replay_state']['passed'];
    if(!$rollback['passed']){throw new RuntimeException('Rollback/replay semantic gate failed');}
    return ['real_missing_parent'=>$race,'atomic_rollback_replay'=>$rollback];
}


function tablePlans(array $node): array {
    $rows=[];
    foreach($node as $key=>$value){if($key==='table' && is_array($value) && ($value['table_name']??null)==='collections'){$rows[]=$value;}if(is_array($value)){$rows=[...$rows,...tablePlans($value)];}}
    return $rows;
}
function normalizeDdl(string $ddl): string {return preg_replace('/\s+/',' ',trim(preg_replace('/\bAUTO_INCREMENT=\d+\b/','',$ddl)));}
function queryPlanGates(string $variant): array {
    $schema=file_get_contents('/bench/full-source-schema.sql');if(!is_string($schema) || !hash_equals((string)getenv('BENCH_PLAN_SCHEMA_SHA'),hash('sha256',$schema))){throw new RuntimeException('Full source schema identity mismatch');}
    DB::statement('SET FOREIGN_KEY_CHECKS=0');foreach(['parts','binaries','collection_groups','collections','collection_regexes','usenet_groups'] as $name){DB::statement('DROP TABLE IF EXISTS '.$name);}DB::statement('SET FOREIGN_KEY_CHECKS=1');foreach(explode(';',$schema) as $sql){if(trim($sql)!==''){DB::statement($sql);}}
    $importDdl=[];foreach(['usenet_groups','collection_regexes','collections','collection_groups','binaries','parts'] as $table){$row=(array)DB::selectOne('SHOW CREATE TABLE '.$table);$importDdl[$table]=(string)array_values($row)[1];}
    $hadObsolete=DB::selectOne("SELECT COUNT(*) n FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='collections' AND INDEX_NAME='collections_dateadded_idx'")->n>0;
    if(!$hadObsolete){throw new RuntimeException('Expected obsolete index missing from source-schema input');}
    if($hadObsolete){DB::statement('ALTER TABLE collections DROP INDEX collections_dateadded_idx');}
    if(DB::selectOne("SELECT COUNT(*) n FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='collections' AND INDEX_NAME='collections_dateadded_idx'")->n!=0){throw new RuntimeException('Obsolete index remains');}
    $effectiveDdl=[];$expectedDdl=[];
    foreach($importDdl as $table=>$original){$expected=$table==='collections'?preg_replace('/\n\s*KEY `collections_dateadded_idx` \(`dateadded`\),?/','',$original,1):$original;$expectedDdl[$table]=normalizeDdl($expected);$row=(array)DB::selectOne('SHOW CREATE TABLE '.$table);$effectiveDdl[$table]=normalizeDdl((string)array_values($row)[1]);if($expectedDdl[$table]!==$effectiveDdl[$table]){throw new RuntimeException('Effective DDL changed beyond declared obsolete-index removal');}}
    DB::table('usenet_groups')->insert([['id'=>1,'name'=>'alt.binaries.plan.a'],['id'=>2,'name'=>'alt.binaries.plan.b']]);
    for($start=1;$start<=1040;$start+=100){$cs=[];$bs=[];$ps=[];for($id=$start;$id<min(1041,$start+100);$id++){$cs[]=['id'=>$id,'subject'=>'Fixture.Plan.'.$id,'fromname'=>'synthetic@example.test','collectionhash'=>sha1('Fixture.Plan.'.$id,true),'groups_id'=>1,'totalfiles'=>1,'filecheck'=>0,'filesize'=>0];$bs[]=['id'=>$id,'collections_id'=>$id,'binaryhash'=>md5('Fixture.Plan.'.$id,true),'name'=>'Fixture.Plan.'.$id,'filenumber'=>1,'totalparts'=>1,'currentparts'=>1,'partcheck'=>1,'partsize'=>1024];$ps[]=['binaries_id'=>$id,'messageid'=>'<plan-'.$id.'@example.test>','number'=>$id,'partnumber'=>1,'size'=>1024];}DB::table('collections')->insert($cs);DB::table('binaries')->insert($bs);DB::table('parts')->insert($ps);}
    $ddl=[];foreach(['collections','binaries','parts','collection_groups'] as $name){$row=(array)DB::selectOne('SHOW CREATE TABLE '.$name);$ddl[$name]=array_values($row)[1];}
    $captured=[];DB::listen(function($q)use(&$captured){if(stripos($q->sql,'for update')!==false && str_contains($q->sql,'`collections`')){$captured[]=['sql'=>$q->sql,'bindings'=>$q->bindings];}});
    $cases=[];
    foreach(['fresh','analyzed'] as $stats){if($stats==='analyzed'){DB::statement('ANALYZE TABLE collections');}foreach(['dense','sparse'] as $shape){foreach([1,2,32,500] as $count){$ids=[];for($n=1;$n<=$count;$n++){$ids[]=$shape==='dense'?$n:$n*2-1;}$captured=[];DB::beginTransaction();try{$handler=new CollectionHandler; $ok=$handler->refreshAggregates($ids,500);$state=DB::table('collections')->whereIn('id',$ids)->where('filecheck',3)->where('filesize',1024)->count();}finally{DB::rollBack();}
        if(!$ok || $state!==$count || count($captured)!==1){throw new RuntimeException('Actual-handler plan query capture failed');}
        $query=$captured[0];if($query['bindings']!==$ids){throw new RuntimeException('Captured locking bindings differ from requested sorted IDs');}$explain=(array)DB::selectOne('EXPLAIN FORMAT=JSON '.$query['sql'],$query['bindings']);$explain=json_decode((string)array_values($explain)[0],true,512,JSON_THROW_ON_ERROR);
        DB::beginTransaction();try{$analysis=(array)DB::selectOne('ANALYZE FORMAT=JSON '.$query['sql'],$query['bindings']);$analysis=json_decode((string)array_values($analysis)[0],true,512,JSON_THROW_ON_ERROR);}finally{DB::rollBack();}
        $tables=tablePlans($analysis);if(count($tables)!==1){throw new RuntimeException('Executed collection plan unavailable');}$plan=$tables[0];$access=$plan['access_type']??null;$key=$plan['key']??null;$actualRows=$plan['r_rows']??null;$loops=$plan['r_loops']??null;
        $primaryBounded=$key==='PRIMARY' && (($access==='const' && $count===1 && $state===1) || (in_array($access,['range','ref','eq_ref'],true) && is_numeric($actualRows) && is_numeric($loops) && $actualRows*$loops<=$count));
        $result=['variant'=>$variant,'statistics'=>$stats==='fresh'?'no_explicit_analyze':$stats,'shape'=>$shape,'wanted_count'=>$count,'wanted_ids'=>$ids,'actual_handler_ok'=>$ok,'actual_aggregate_rows'=>$state,'query'=>$query,'explain'=>$explain,'executed_analyze'=>$analysis,'key'=>$key,'access_type'=>$access,'reported_rows_processed'=>$actualRows,'reported_loops'=>$loops,'row_counter_status'=>is_numeric($actualRows)?'reported':'unavailable_for_this_plan','candidate_primary_bounded'=>$primaryBounded];$cases[]=$result;
        if($variant==='candidate' && !$primaryBounded){file_put_contents('/bench/plan-gate-partial.json',json_encode(['cases'=>$cases],JSON_PRETTY_PRINT));throw new RuntimeException('Candidate PRIMARY access gate failed');}
    }}}
    return ['schema_profile'=>'source DDL; deployed parity unverified','schema_input_sha256'=>hash('sha256',$schema),'obsolete_index_existed_before_drop'=>$hadObsolete,'obsolete_index_dropped'=>$hadObsolete,'normalized_effective_ddl'=>$effectiveDdl,'expected_normalized_ddl'=>$expectedDdl,'effective_ddl'=>$ddl,'cases'=>$cases,'passed'=>count($cases)===16];
}


function sqlCategory(string $sql): string {
    $s=strtolower(str_replace('`','',ltrim($sql)));
    if(str_starts_with($s,'select') && str_contains($s,'for update')){return str_contains($s,'from collections')?'collection_lock':'binary_lock';}
    if(str_starts_with($s,'select') && str_contains($s,'sum(')){return str_contains($s,'from parts')?'parts_aggregate_read':'binary_aggregate_read';}
    if(str_starts_with($s,'update collections')){return 'collection_update';}
    if(str_starts_with($s,'update binaries')){return 'binary_update';}
    if(str_starts_with($s,'insert into collections')){return 'collection_upsert';}
    if(str_starts_with($s,'insert into binaries')){return 'binary_upsert';}
    if(str_starts_with($s,'insert ignore into parts')){return 'parts_insert';}
    if(str_contains($s,'collection_groups') && str_starts_with($s,'insert')){return 'crosspost_write';}
    return 'other_successful_sql';
}

function percentile(array $v,float $p): float {sort($v);return $v[max(0,(int)ceil(count($v)*$p)-1)]??0;}
foreach(['/bench/worker-*.json','/bench/ready-*','/bench/go-*'] as $pattern){foreach(glob($pattern) as $old){unlink($old);}}
connectApp();date_default_timezone_set('UTC');
@mkdir('/bench/runtime-extensions',0700);foreach(['pcntl','pdo_mysql'] as $ext){$src=ini_get('extension_dir').'/'.$ext.'.so';if(is_file($src)){copy($src,'/bench/runtime-extensions/'.$ext.'.so');}}
$report=['php_ini_snapshot'=>['version'=>PHP_VERSION,'zts'=>PHP_ZTS,'opcache_enable'=>ini_get('opcache.enable'),'opcache_enable_cli'=>ini_get('opcache.enable_cli'),'jit'=>ini_get('opcache.jit'),'jit_buffer_size'=>ini_get('opcache.jit_buffer_size')],'start_utc'=>gmdate('c'),'server_version'=>DB::selectOne('SELECT VERSION() AS v')->v,'source_hashes'=>[],'cases'=>[]];
foreach(['HeaderStorageService','CollectionHandler','BinaryHandler','PartHandler'] as $f){$report['source_hashes'][$f]=hash_file('sha256','<machine-path>'.$f.'.php');}
DB::statement('CREATE TEMPORARY TABLE returning_probe(id INT PRIMARY KEY,size INT) ENGINE=InnoDB');
DB::statement('INSERT INTO returning_probe VALUES(1,10)');
$rt=DB::select('INSERT IGNORE INTO returning_probe VALUES(1,99),(2,20) RETURNING id,size',[],false);
DB::beginTransaction();DB::select('INSERT IGNORE INTO returning_probe VALUES(3,30) RETURNING id,size',[],false);DB::rollBack();
$originalReturningSize=(int)DB::table('returning_probe')->where('id',1)->value('size');
$report['returning_probe']=['original_duplicate_size'=>$originalReturningSize,'rows'=>$rt,'rollback_preserved'=>DB::table('returning_probe')->count()===2,'passed'=>$originalReturningSize===10 && count($rt)===1 && (int)$rt[0]->id===2 && (int)$rt[0]->size===20 && DB::table('returning_probe')->count()===2];
if(getenv('BENCH_SEMANTICS')==='1'){$report['semantic_gates']=semanticGates();file_put_contents('/bench/semantic-gates.json',json_encode($report['semantic_gates'],JSON_PRETTY_PRINT));DB::disconnect();connectApp();}
$matrix=[[4,500],[6,500],[12,500],[4,100],[6,100],[12,100]];

$selected=json_decode((string)getenv('BENCH_CASE_JSON'),true,512,JSON_THROW_ON_ERROR);
foreach(['repeat','collections','workers','header_chunk','identity','variant','handler_sha256'] as $field){if(!array_key_exists($field,$selected)){throw new RuntimeException('Missing case field: '.$field);}}
if(!in_array($selected['collections'],[2,32],true) || $selected['workers']!==4 || $selected['header_chunk']!==500 || (!is_int($selected['repeat']) || $selected['repeat']<0 || $selected['repeat']>19) || !in_array($selected['variant'],['baseline','candidate'],true)){throw new RuntimeException('Invalid case selection');}
if(hash_file('sha256','<machine-path>')!==$selected['handler_sha256']){throw new RuntimeException('Selected source hash mismatch');}
if(!$report['returning_probe']['passed']){throw new RuntimeException('Capability/rollback probe failed');}
$report['selection']=$selected;if(!is_array($selected['source_hashes']??null) || count($selected['source_hashes'])!==count($report['source_hashes'])){throw new RuntimeException('Storage source manifest mismatch');}foreach($report['source_hashes'] as $name=>$hash){if(!isset($selected['source_hashes'][$name]) || !is_string($selected['source_hashes'][$name]) || !hash_equals($hash,$selected['source_hashes'][$name])){throw new RuntimeException('Storage source manifest mismatch');}}

if(getenv('BENCH_PLAN_GATE')==='1'){$report['plan_gate']=queryPlanGates($selected['variant']);$report['execution_complete']=true;file_put_contents('/bench/report.json',json_encode($report,JSON_PRETTY_PRINT));echo json_encode(['plan_gate_passed'=>$report['plan_gate']['passed'],'cases'=>count($report['plan_gate']['cases'])]),PHP_EOL;exit(0);}
$overallStart=microtime(true);
for($repeat=$selected['repeat'];$repeat<=$selected['repeat'];$repeat++){
    foreach([$selected['collections']] as $collections){
        $order=[[$selected['workers'],$selected['header_chunk']]];
        foreach($order as [$workers,$chunk]){
            if(microtime(true)-$overallStart>480){throw new RuntimeException('Benchmark total runtime bound reached');}
            resetSchema();$canonical=headers($collections);
            $seed=array_values(array_filter($canonical,fn($h)=>(int)$h['matches'][2]<=intdiv((int)$h['matches'][3],10)));
            $seedLockQueries=[];DB::listen(function($q)use(&$seedLockQueries){if(stripos($q->sql,'for update')!==false && str_contains($q->sql,'`collections`')){$seedLockQueries[]=['sql'=>$q->sql,'bindings'=>$q->bindings];}});
            $failed=service(500)->store($seed,['id'=>1,'name'=>'alt.binaries.bench.a']);
            if($failed!==[]){throw new RuntimeException('Seed failed');}
            $seededParts=(int)DB::table('parts')->count();if($seededParts!==count($seed)){throw new RuntimeException('Seed part-count mismatch');}
            if($seedLockQueries===[]){throw new RuntimeException('Actual historical fixture lock query absent');}
            $seedLockQuery=end($seedLockQueries);$planRaw=(array)DB::selectOne('EXPLAIN FORMAT=JSON '.$seedLockQuery['sql'],$seedLockQuery['bindings']);$fixtureExplain=json_decode((string)array_values($planRaw)[0],true,512,JSON_THROW_ON_ERROR);
            DB::beginTransaction();try{$planRaw=(array)DB::selectOne('ANALYZE FORMAT=JSON '.$seedLockQuery['sql'],$seedLockQuery['bindings']);$fixtureAnalyze=json_decode((string)array_values($planRaw)[0],true,512,JSON_THROW_ON_ERROR);}finally{DB::rollBack();}
            $fixturePlan=['table_collection_count'=>(int)DB::table('collections')->count(),'schema_profile'=>'historical six-table fixture after canonical partial seed','query'=>$seedLockQuery,'explain'=>$fixtureExplain,'executed_analyze'=>$fixtureAnalyze,'outside_timed_interval'=>true];
            $work=[...$canonical,...array_slice($canonical,0,2048)];mt_srand(42);shuffle($work);
            $caseId=count($report['cases']);DB::disconnect();
            $go=microtime(true)+0.35;$pids=[];
            for($w=0;$w<$workers;$w++){
                $pid=pcntl_fork();if($pid===-1){throw new RuntimeException('fork failed');}
                if($pid===0){
                    try{
                        connectApp();$svc=service($chunk);$mine=[];
                        foreach($work as $i=>$h){if($i%$workers===$w){$mine[]=$h;}}
                        $queries=0;$queryMs=0.;$queryCategories=[];DB::listen(function($q)use(&$queries,&$queryMs,&$queryCategories){$queries++;$queryMs+=$q->time;$category=sqlCategory($q->sql);$queryCategories[$category]??=['count'=>0,'time_ms'=>0.];$queryCategories[$category]['count']++;$queryCategories[$category]['time_ms']+=$q->time;});
                        file_put_contents("/bench/ready-{$caseId}-{$w}",'ready');
                        $barrier="/bench/go-{$caseId}";$limit=microtime(true)+20;
                        while(!is_file($barrier)){if(microtime(true)>$limit){throw new RuntimeException('start barrier timeout');}usleep(1000);}
                        $latency=[];$failedCount=0;$failedIds=[];$usageBefore=getrusage();$gcBefore=gc_status();$peakBefore=memory_get_peak_usage(true);$begin=microtime(true);
                        foreach(array_chunk($mine,$chunk) as $batch){$start=microtime(true);$failedBatch=$svc->store($batch,['id'=>$w%2+1,'name'=>$w%2===0?'alt.binaries.bench.a':'alt.binaries.bench.b']);$failedCount+=count($failedBatch);$failedIds=[...$failedIds,...$failedBatch];$latency[]=(microtime(true)-$start)*1000;}
                        $workerElapsed=microtime(true)-$begin;$usageAfter=getrusage();$gcAfter=gc_status();$peakAfter=memory_get_peak_usage(true);
                        file_put_contents("/bench/worker-{$caseId}-{$w}.json",json_encode(['rusage_before'=>$usageBefore,'rusage_after'=>$usageAfter,'gc_before'=>$gcBefore,'gc_after'=>$gcAfter,'peak_memory_before'=>$peakBefore,'peak_memory_after'=>$peakAfter,'case_identity'=>$selected['identity'],'worker'=>$w,'seconds'=>$workerElapsed,'latency_ms'=>$latency,'failed_headers'=>$failedCount,'failed_article_ids'=>array_values(array_unique($failedIds)),'rollback_records'=>app('log')->issues,'queries'=>$queries,'query_ms'=>$queryMs,'query_categories'=>$queryCategories,'driver_errors'=>app('log')->driverErrors]));exit(0);
                    }catch(Throwable $e){file_put_contents("/bench/worker-{$caseId}-{$w}.json",json_encode(['case_identity'=>$selected['identity'],'worker'=>$w,'error'=>$e->getMessage()]));exit(1);}
                }
                $pids[]=$pid;
            }
            $limit=microtime(true)+20;
            do{$ready=0;for($w=0;$w<$workers;$w++){$ready+=(int)is_file("/bench/ready-{$caseId}-{$w}");}if($ready===$workers){break;}if(microtime(true)>$limit){foreach($pids as $pid){posix_kill($pid,SIGTERM);}throw new RuntimeException('worker preparation timeout');}usleep(1000);}while(true);
            $clockBefore=(array)DB::selectOne('SELECT NOW(6) AS database_now, UTC_TIMESTAMP(6) AS database_utc, UNIX_TIMESTAMP(NOW(6)) AS epoch_seconds');$lastSeenBefore=DB::table('collections')->orderBy('id')->pluck('last_seen_at','id')->all();$before=counters();$cpuBefore=cpuSnapshot();$wallStart=microtime(true);file_put_contents("/bench/go-{$caseId}",'go');
            $statuses=[];$normalExits=[];$signals=[];$remaining=array_fill_keys($pids,true);$joinDeadline=microtime(true)+60;
            while($remaining!==[]){foreach(array_keys($remaining) as $pid){$joined=pcntl_waitpid($pid,$status,WNOHANG);if($joined===$pid){$statuses[]=pcntl_wifexited($status)?pcntl_wexitstatus($status):255;$normalExits[]=pcntl_wifexited($status);$signals[]=pcntl_wifsignaled($status)?pcntl_wtermsig($status):0;unset($remaining[$pid]);}elseif($joined===-1){throw new RuntimeException('Child join failed');}}if(microtime(true)>$joinDeadline){foreach(array_keys($remaining) as $pid){posix_kill($pid,SIGKILL);pcntl_waitpid($pid,$status);}file_put_contents('/bench/incomplete.json',json_encode(['classification'=>'harness_invalid','reason'=>'worker_join_timeout','selection'=>$selected]));throw new RuntimeException('Worker join timeout');}if($remaining!==[]){usleep(1000);}}
            $wallElapsed=microtime(true)-$wallStart;$cpuAfter=cpuSnapshot();connectApp();$after=counters();$clockAfter=(array)DB::selectOne('SELECT NOW(6) AS database_now, UTC_TIMESTAMP(6) AS database_utc, UNIX_TIMESTAMP(NOW(6)) AS epoch_seconds');$lastSeenAfter=DB::table('collections')->orderBy('id')->pluck('last_seen_at','id')->all();$changedSeen=0;foreach($lastSeenBefore as $id=>$value){if(($lastSeenAfter[$id]??null)!==$value){$changedSeen++;}}$lat=[];$failedCount=0;$queries=0;$queryMs=0.;$seconds=0.;$errors=[];$allFailedIds=[];$rollbackRecords=[];$queryCategories=[];$driverErrors=[];$workerDiagnostics=[];
            for($w=0;$w<$workers;$w++){$workerFile="/bench/worker-{$caseId}-{$w}.json";if(!is_file($workerFile)){throw new RuntimeException('Missing worker artifact');}$d=json_decode(file_get_contents($workerFile),true,512,JSON_THROW_ON_ERROR);if(($d['case_identity']??null)!==$selected['identity'] || ($d['worker']??null)!==$w){throw new RuntimeException('Worker identity mismatch');}if(!isset($d['error'])){foreach(['seconds','latency_ms','failed_headers','failed_article_ids','rollback_records','queries','query_ms','query_categories','driver_errors'] as $field){if(!array_key_exists($field,$d)){throw new RuntimeException('Malformed worker artifact');}}foreach(['latency_ms','failed_article_ids','rollback_records','query_categories','driver_errors'] as $field){if(!is_array($d[$field])){throw new RuntimeException('Invalid worker array');}}foreach(['seconds','failed_headers','queries','query_ms'] as $field){if(!is_numeric($d[$field]) || $d[$field]<0){throw new RuntimeException('Invalid worker counter');}}}if(isset($d['error'])){$errors[]=$d['error'];continue;}$workerDiagnostics[]=['worker'=>$w,'rusage_before'=>$d['rusage_before'],'rusage_after'=>$d['rusage_after'],'gc_before'=>$d['gc_before'],'gc_after'=>$d['gc_after'],'peak_memory_before'=>$d['peak_memory_before'],'peak_memory_after'=>$d['peak_memory_after']];$lat=[...$lat,...$d['latency_ms']];$failedCount+=$d['failed_headers'];$allFailedIds=[...$allFailedIds,...$d['failed_article_ids']];$rollbackRecords=[...$rollbackRecords,...$d['rollback_records']];$queries+=$d['queries'];$queryMs+=$d['query_ms'];foreach($d['query_categories'] as $category=>$metrics){$queryCategories[$category]??=['count'=>0,'time_ms'=>0.];$queryCategories[$category]['count']+=$metrics['count'];$queryCategories[$category]['time_ms']+=$metrics['time_ms'];}$driverErrors=[...$driverErrors,...$d['driver_errors']];$seconds=max($seconds,$d['seconds']);}
            $check=verify($canonical,$collections);$snapshot=null;if(!$check['passed'] || $failedCount>0){$snapshot='deadlock-case-'.$caseId.'.txt';$status=DB::selectOne('SHOW ENGINE INNODB STATUS');file_put_contents('/bench/'.$snapshot,implode('\n',array_values((array)$status)));}
            $replayFailed=service($chunk)->store($canonical,['id'=>1,'name'=>'alt.binaries.bench.a']);$replayCheck=verify($canonical,$collections);
            $conflicts=array_slice($canonical,0,128);foreach($conflicts as &$h){$h['Bytes']+=777;$h['Message-ID']='<conflict-'.$h['Number'].'@example.test>';}unset($h);$conflictFailed=service($chunk)->store($conflicts,['id'=>2,'name'=>'alt.binaries.bench.b']);$conflictCheck=verify($canonical,$collections);$firstWritePassed=$conflictFailed===[] && $conflictCheck['passed'] && DB::table('parts')->where('messageid','like','<conflict-%')->count()===0;
            $delta=[];foreach($after as $k=>$v){$delta[$k]=$v-$before[$k];}
            $r=['clock_before'=>$clockBefore,'clock_after'=>$clockAfter,'last_seen_before'=>$lastSeenBefore,'last_seen_after'=>$lastSeenAfter,'last_seen_changed_count'=>$changedSeen,'clock_diagnostic_scope'=>'outside measured CPU/wall interval; no frozen time','worker_diagnostics'=>$workerDiagnostics,'storage_batch_latency_ms'=>$lat,'historical_fixture_plan'=>$fixturePlan,'successful_query_categories'=>$queryCategories,'query_category_limit'=>'QueryExecuted excludes failed SQL and retry/backoff; worker times overlap','observed_driver_error_codes'=>$driverErrors,'selection'=>$selected,'cpu_before'=>$cpuBefore,'cpu_after'=>$cpuAfter,'actual_seeded_parts'=>$seededParts,'execution_complete'=>true,'harness_valid'=>true,'repeat'=>$repeat+1,'collections'=>$collections,'workers'=>$workers,'header_chunk'=>$chunk,'sql_chunk'=>500,'attempted_headers'=>count($work),'new_unique_headers'=>10240-count($seed),'seconds'=>round($wallElapsed,4),'worker_max_elapsed_seconds'=>round($seconds,4),'unique_headers_per_second'=>round((10240-count($seed))/max($wallElapsed,.000001),1),'p50_storage_batch_ms'=>round(percentile($lat,.50),2),'p95_storage_batch_ms'=>round(percentile($lat,.95),2),'max_storage_batch_ms'=>round(max($lat?:[0]),2),'transactions'=>count($lat),'queries'=>$queries,'summed_query_ms'=>round($queryMs,1),'failed_headers'=>$failedCount,'failed_article_count_unique'=>count(array_unique($allFailedIds)),'failed_article_ids'=>array_values(array_unique($allFailedIds)),'rollback_records'=>$rollbackRecords,'deadlock_snapshot_file'=>$snapshot,'actual_new_unique_parts'=>max(0,$check['parts']-count($seed)),'actual_committed_unique_parts_per_second'=>round(max(0,$check['parts']-count($seed))/$wallElapsed,1),'child_errors'=>$errors,'child_exit_codes'=>$statuses,'child_normal_exits'=>$normalExits,'child_signals'=>$signals,'lock_counters'=>$delta,'correctness'=>$check,'conflicting_duplicate_first_write_passed'=>$firstWritePassed,'replay_passed'=>$replayFailed===[] && $replayCheck['passed']];
            $r['valid_initial_storage_run']=$firstWritePassed && $check['passed'] && $r['replay_passed'] && $failedCount===0 && $errors===[] && array_sum($statuses)===0 && !in_array(false,$normalExits,true) && array_sum($signals)===0;if(!$r['valid_initial_storage_run']){$r['unique_headers_per_second']=null;}
            $report['cases'][]=$r;file_put_contents('/bench/report.json',json_encode($report,JSON_PRETTY_PRINT));echo json_encode($r),PHP_EOL;
            if(!$firstWritePassed || !$check['passed'] || !$r['replay_passed'] || $failedCount>0 || $errors!==[] || array_sum($statuses)!==0 || in_array(false,$normalExits,true) || array_sum($signals)!==0){echo json_encode(['case_invalid_for_performance_ranking'=>$caseId]),PHP_EOL;}
        }
    }
}
$report['execution_complete']=true;$report['harness_valid']=true;$report['end_utc']=gmdate('c');file_put_contents('/bench/report.json',json_encode($report,JSON_PRETTY_PRINT));
