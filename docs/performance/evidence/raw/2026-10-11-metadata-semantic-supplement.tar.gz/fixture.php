<?php

declare(strict_types=1);

use App\Services\Binaries\BinariesConfig;
use App\Services\Binaries\HeaderStorageService;
use App\Services\Tmux\CollectionDowntimeCompensator;
use Illuminate\Contracts\Console\Kernel;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

function semanticCheck(bool $condition, string $label, mixed $expected = null, mixed $actual = null): void
{
    if (! $condition) {
        throw new RuntimeException($label.' expected='.json_encode($expected, JSON_THROW_ON_ERROR).' actual='.json_encode($actual, JSON_THROW_ON_ERROR));
    }
}

function semanticHeaders(array $groupTokens, string $timeOne, string $timeTwo): array
{
    $headers = [];
    $number = 12000;
    foreach (['Semantic Alpha', 'Semantic Beta'] as $collectionOffset => $name) {
        foreach (range(1, 4) as $fileNumber) {
            foreach (range(1, 2) as $partNumber) {
                $number++;
                $subject = $name.' ['.$fileNumber.'/4] ('.$partNumber.'/2)';
                preg_match('/^\s*(?!Usenet Index Post)(.+?)\s+\((\d+)\/(\d+)\)/', $subject, $matches);
                if (stripos($subject, 'yEnc') === false) {
                    $matches[1] .= ' yEnc';
                }
                $xref = ['news.example.invalid'];
                foreach ($groupTokens as $group) {
                    $xref[] = $group.':'.$number;
                }
                $xref[] = $groupTokens[0].':'.$number;
                $headers[] = [
                    'Number' => $number,
                    'Subject' => $subject,
                    'From' => 'poster@example.invalid',
                    'Date' => strtotime(($collectionOffset === 0 ? $timeOne : $timeTwo).' UTC'),
                    'Bytes' => 100 + ($collectionOffset * 100) + ($fileNumber * 10) + $partNumber,
                    'Message-ID' => '<semantic-'.$collectionOffset.'-'.$fileNumber.'-'.$partNumber.'@example.invalid>',
                    'Xref' => implode(' ', $xref),
                    'matches' => $matches,
                ];
            }
        }
    }

    return $headers;
}

function mapCollectionIds(): array
{
    $ids = [];
    foreach (DB::table('collections')->select(['id', 'subject', 'totalfiles'])->orderBy('id')->get() as $row) {
        $subject = (string) $row->subject;
        $family = str_starts_with($subject, 'Semantic Alpha') ? 'Semantic Alpha'
            : (str_starts_with($subject, 'Semantic Beta') ? 'Semantic Beta' : null);
        semanticCheck($family !== null, 'collection family recognized', ['Semantic Alpha', 'Semantic Beta'], $subject);
        semanticCheck((int) $row->totalfiles === 4, 'file total for '.$family, 4, (int) $row->totalfiles);
        semanticCheck(! isset($ids[$family]), 'one collection ID for '.$family, null, $row->id);
        $ids[$family] = (int) $row->id;
    }
    ksort($ids);

    return $ids;
}

function normalizedGroupMembership(array $collectionIds): array
{
    $actual = array_fill_keys(array_values($collectionIds), []);
    foreach (DB::table('collection_groups')
        ->selectRaw('collections_id, LOWER(group_name) AS normalized_group_name')
        ->orderBy('collections_id')->orderBy('normalized_group_name')->get() as $row) {
        $actual[(int) $row->collections_id][] = (string) $row->normalized_group_name;
    }
    foreach ($actual as &$groups) {
        $groups = array_values(array_unique($groups));
        sort($groups);
    }
    unset($groups);
    ksort($actual);

    return $actual;
}

function expectedMembership(array $collectionIds, array $groups): array
{
    $expected = [];
    foreach ($collectionIds as $id) {
        $expected[(int) $id] = $groups;
    }
    ksort($expected);

    return $expected;
}

function normalizePartRows(): array
{
    $rows = DB::table('parts')->select(['binaries_id', 'number', 'messageid', 'partnumber', 'size'])
        ->orderBy('binaries_id')->orderBy('partnumber')->get();

    return array_map(static fn (object $row): array => [
        (int) $row->binaries_id,
        (int) $row->number,
        (string) $row->messageid,
        (int) $row->partnumber,
        (int) $row->size,
    ], $rows->all());
}

function verifyStoredState(array $collectionIds, array $expectedSizeByFamily, array $expectedBinarySizes): array
{
    semanticCheck(count($collectionIds) === 2, 'exact collection count', 2, count($collectionIds));
    semanticCheck(DB::table('binaries')->count() === 8, 'exact binary count', 8, DB::table('binaries')->count());
    semanticCheck(DB::table('parts')->count() === 16, 'exact part count', 16, DB::table('parts')->count());
    semanticCheck(DB::table('collections')->where('filecheck', 3)->count() === 2, 'all collections ready', 2, DB::table('collections')->where('filecheck', 3)->count());

    $collections = DB::table('collections')->select(['id', 'subject', 'filesize', 'filecheck', 'last_seen_at', 'dateadded', 'totalfiles'])->orderBy('id')->get();
    $lastSeen = [];
    $dateAdded = [];
    foreach ($collections as $row) {
        $family = str_starts_with((string) $row->subject, 'Semantic Alpha') ? 'Semantic Alpha' : 'Semantic Beta';
        semanticCheck((int) $row->filesize === $expectedSizeByFamily[$family], 'collection aggregate '.$family, $expectedSizeByFamily[$family], (int) $row->filesize);
        semanticCheck((int) $row->filecheck === 3, 'collection readiness '.$family, 3, (int) $row->filecheck);
        semanticCheck((int) $row->totalfiles === 4, 'collection totalfiles '.$family, 4, (int) $row->totalfiles);
        $lastSeen[$family] = (string) $row->last_seen_at;
        $dateAdded[$family] = (string) $row->dateadded;
    }

    $binaryRows = DB::table('binaries as b')
        ->leftJoin('parts as p', 'p.binaries_id', '=', 'b.id')
        ->selectRaw('b.id, b.collections_id, b.filenumber, b.totalparts, b.currentparts, b.partcheck, b.partsize, COUNT(p.binaries_id) AS actualparts, COALESCE(SUM(p.size), 0) AS actualsize')
        ->groupBy('b.id', 'b.collections_id', 'b.filenumber', 'b.totalparts', 'b.currentparts', 'b.partcheck', 'b.partsize')
        ->orderBy('b.collections_id')->orderBy('b.filenumber')->get();
    $binarySummaries = [];
    foreach ($binaryRows as $row) {
        $family = (int) $row->collections_id === $collectionIds['Semantic Alpha'] ? 'Semantic Alpha' : 'Semantic Beta';
        $file = (int) $row->filenumber;
        $expected = $expectedBinarySizes[$family][$file] ?? null;
        semanticCheck($expected !== null, 'binary file identity', array_keys($expectedBinarySizes[$family]), $file);
        semanticCheck((int) $row->totalparts === 2, 'binary totalparts', 2, (int) $row->totalparts);
        semanticCheck((int) $row->currentparts === 2, 'binary currentparts', 2, (int) $row->currentparts);
        semanticCheck((int) $row->partcheck === 1, 'binary completion flag', 1, (int) $row->partcheck);
        semanticCheck((int) $row->actualparts === 2, 'binary actual part rows', 2, (int) $row->actualparts);
        semanticCheck((int) $row->partsize === $expected, 'binary stored partsize', $expected, (int) $row->partsize);
        semanticCheck((int) $row->actualsize === $expected, 'binary computed part size', $expected, (int) $row->actualsize);
        $binarySummaries[] = [
            'collections_id' => (int) $row->collections_id,
            'filenumber' => $file,
            'totalparts' => (int) $row->totalparts,
            'currentparts' => (int) $row->currentparts,
            'partcheck' => (int) $row->partcheck,
            'partsize' => (int) $row->partsize,
        ];
    }
    semanticCheck(count($binarySummaries) === 8, 'binary summary count', 8, count($binarySummaries));

    $orphanParts = DB::table('parts as p')->leftJoin('binaries as b', 'b.id', '=', 'p.binaries_id')->whereNull('b.id')->count();
    $orphanBinaries = DB::table('binaries as b')->leftJoin('collections as c', 'c.id', '=', 'b.collections_id')->whereNull('c.id')->count();
    semanticCheck($orphanParts === 0 && $orphanBinaries === 0, 'orphan count', [0, 0], [$orphanParts, $orphanBinaries]);

    ksort($lastSeen);
    ksort($dateAdded);

    return ['last_seen_at' => $lastSeen, 'dateadded' => $dateAdded, 'binaries' => $binarySummaries];
}

$root = getcwd();
require $root.'/vendor/autoload.php';
$schemaFile = $argv[1] ?? '<machine-path>';
$variant = getenv('VALIDATION_VARIANT') ?: 'unspecified';
$dbName = 'nntmux_semantic_'.bin2hex(random_bytes(6));
$createdDatabase = false;
$markerDirectory = sys_get_temp_dir().'/nntmux-semantic-marker-'.bin2hex(random_bytes(8));
$markerPath = $markerDirectory.'/marker';
$timeOne = '2026-10-12 03:00:00';
$timeTwo = '2026-10-12 03:02:00';
$handlerHash = hash_file('sha256', $root.'<machine-path>');
$sourceHash = (string) (getenv('SOURCE_REVISION') ?: '');

try {
    $app = require $root.'/bootstrap/app.php';
    $app->make(Kernel::class)->bootstrap();
    config(['app.timezone' => 'UTC', 'database.default' => 'mysql']);
    date_default_timezone_set('UTC');
    config(['database.connections.mysql' => [
        'driver' => 'mysql', 'url' => null, 'host' => getenv('TEST_MARIADB_HOST') ?: 'db',
        'port' => '3306', 'database' => 'information_schema', 'username' => 'root',
        'password' => 'isolated-validation', 'unix_socket' => '', 'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci', 'prefix' => '', 'prefix_indexes' => true,
        'strict' => true, 'engine' => null, 'options' => [],
    ]]);
    DB::purge('mysql');
    DB::setDefaultConnection('mysql');
    DB::reconnect('mysql');
    DB::statement("SET SESSION time_zone = '+00:00'");
    DB::statement("CREATE DATABASE `{$dbName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $createdDatabase = true;
    config(['database.connections.mysql.database' => $dbName]);
    DB::purge('mysql');
    DB::reconnect('mysql');
    DB::statement("SET SESSION time_zone = '+00:00'");
    foreach (array_filter(array_map('trim', explode(';', file_get_contents($schemaFile)))) as $statement) {
        DB::unprepared($statement);
    }
    DB::table('usenet_groups')->insert(['id' => 1, 'name' => 'alt.binaries.a']);
    if (! is_dir($markerDirectory) && ! mkdir($markerDirectory, 0700, true) && ! is_dir($markerDirectory)) {
        throw new RuntimeException('Could not create isolated activity marker directory.');
    }
    $app->instance(CollectionDowntimeCompensator::class, new CollectionDowntimeCompensator($markerPath));

    $baseHeaders = semanticHeaders(['alt.binaries.a', 'alt.binaries.b', 'ALT.BINARIES.A'], $timeOne, $timeTwo);
    $replayHeaders = semanticHeaders(['alt.binaries.a', 'alt.binaries.b', 'alt.binaries.c', 'ALT.BINARIES.A', 'ALT.BINARIES.C'], $timeOne, $timeTwo);
    $expectedSizeByFamily = ['Semantic Alpha' => 0, 'Semantic Beta' => 0];
    $expectedBinarySizes = ['Semantic Alpha' => [], 'Semantic Beta' => []];
    foreach ($baseHeaders as $header) {
        $family = str_starts_with((string) $header['matches'][1], 'Semantic Alpha') ? 'Semantic Alpha' : 'Semantic Beta';
        preg_match('/\[(\d+)\/4\]/', (string) $header['matches'][1], $fileMatch);
        $file = (int) $fileMatch[1];
        $expectedSizeByFamily[$family] += (int) $header['Bytes'];
        $expectedBinarySizes[$family][$file] = ($expectedBinarySizes[$family][$file] ?? 0) + (int) $header['Bytes'];
    }

    $freeze = static function (string $time): void {
        Carbon::setTestNow(Carbon::parse($time, 'UTC'));
        $epoch = Carbon::parse($time, 'UTC')->getTimestamp();
        DB::statement('SET timestamp = '.$epoch);
        $sqlNow = (string) DB::selectOne('SELECT DATE_FORMAT(NOW(), "%Y-%m-%d %H:%i:%s") AS sql_now')->sql_now;
        semanticCheck($sqlNow === $time, 'private SQL session NOW()', $time, $sqlNow);
    };

    $freeze($timeOne);
    $firstFailures = (new HeaderStorageService(config: new BinariesConfig(headerChunkSize: 20, sqlChunkSize: 50)))->store($baseHeaders, ['id' => 1, 'name' => 'alt.binaries.a'], false);
    semanticCheck($firstFailures === [], 'initial failed article list', [], $firstFailures);
    $collectionIds = mapCollectionIds();
    $groupsAandB = expectedMembership($collectionIds, ['alt.binaries.a', 'alt.binaries.b']);
    $firstMembership = normalizedGroupMembership($collectionIds);
    semanticCheck($firstMembership === $groupsAandB, 'initial exact normalized collection-group membership', $groupsAandB, $firstMembership);
    $firstState = verifyStoredState($collectionIds, $expectedSizeByFamily, $expectedBinarySizes);
    semanticCheck($firstState['last_seen_at'] === ['Semantic Alpha' => $timeOne, 'Semantic Beta' => $timeOne], 'initial per-collection last_seen_at', ['Semantic Alpha' => $timeOne, 'Semantic Beta' => $timeOne], $firstState['last_seen_at']);
    $initialParts = normalizePartRows();
    $initialCollections = DB::table('collections')->select(['id', 'subject', 'dateadded', 'last_seen_at', 'filesize', 'filecheck'])->orderBy('id')->get()->map(static fn (object $row): array => [(int) $row->id, (string) $row->subject, (string) $row->dateadded, (string) $row->last_seen_at, (int) $row->filesize, (int) $row->filecheck])->all();

    $freeze($timeTwo);
    $replayFailures = (new HeaderStorageService(config: new BinariesConfig(headerChunkSize: 20, sqlChunkSize: 50)))->store($replayHeaders, ['id' => 1, 'name' => 'alt.binaries.a'], false);
    semanticCheck($replayFailures === [], 'replay failed article list', [], $replayFailures);
    $replayCollectionIds = mapCollectionIds();
    semanticCheck($replayCollectionIds === $collectionIds, 'collection IDs remain stable on replay', $collectionIds, $replayCollectionIds);
    $groupsAandBandC = expectedMembership($collectionIds, ['alt.binaries.a', 'alt.binaries.b', 'alt.binaries.c']);
    $replayMembership = normalizedGroupMembership($collectionIds);
    semanticCheck($replayMembership === $groupsAandBandC, 'replay exact normalized collection-group membership', $groupsAandBandC, $replayMembership);
    $replayState = verifyStoredState($collectionIds, $expectedSizeByFamily, $expectedBinarySizes);
    semanticCheck($replayState['last_seen_at'] === ['Semantic Alpha' => $timeTwo, 'Semantic Beta' => $timeTwo], 'replay advanced per-collection last_seen_at', ['Semantic Alpha' => $timeTwo, 'Semantic Beta' => $timeTwo], $replayState['last_seen_at']);
    semanticCheck($replayState['dateadded'] === $firstState['dateadded'], 'replay preserved original dateadded values', $firstState['dateadded'], $replayState['dateadded']);
    $replayedParts = normalizePartRows();
    semanticCheck($replayedParts === $initialParts, 'identical part IDs preserve all part identities and sizes', $initialParts, $replayedParts);
    $finalCollections = DB::table('collections')->select(['id', 'subject', 'dateadded', 'last_seen_at', 'filesize', 'filecheck'])->orderBy('id')->get()->map(static fn (object $row): array => [(int) $row->id, (string) $row->subject, (string) $row->dateadded, (string) $row->last_seen_at, (int) $row->filesize, (int) $row->filecheck])->all();
    semanticCheck(count($finalCollections) === 2, 'final exact collection count', 2, count($finalCollections));

    $result = [
        'status' => 'passed', 'variant' => $variant, 'source_revision' => $sourceHash,
        'collection_handler_sha256' => $handlerHash, 'schema_sha256' => hash_file('sha256', $schemaFile),
        'private_database' => 'created and dropped in this run', 'clock_control' => [
            'php_carbon_test_now' => [$timeOne, $timeTwo], 'mariadb_session_set_timestamp' => [$timeOne, $timeTwo],
            'verified_sql_now' => true,
        ],
        'fixture' => ['collections' => 2, 'binaries' => 8, 'parts' => 16, 'headers_each_pass' => 16,
            'initial_groups_per_collection' => ['alt.binaries.a', 'alt.binaries.b'],
            'replay_groups_per_collection' => ['alt.binaries.a', 'alt.binaries.b', 'alt.binaries.c'],
            'duplicate_and_case_variant_xref_tokens' => true],
        'initial' => ['collection_ids' => $collectionIds, 'expected_group_pairs' => $groupsAandB,
            'actual_normalized_group_pairs' => $firstMembership, 'failed_articles' => $firstFailures,
            'last_seen_at' => $firstState['last_seen_at'], 'parts_sha256' => hash('sha256', json_encode($initialParts, JSON_THROW_ON_ERROR))],
        'replay' => ['collection_ids' => $replayCollectionIds, 'expected_group_pairs' => $groupsAandBandC,
            'actual_normalized_group_pairs' => $replayMembership, 'failed_articles' => $replayFailures,
            'last_seen_at' => $replayState['last_seen_at'], 'dateadded_preserved' => true,
            'parts_unchanged' => $initialParts === $replayedParts,
            'parts_sha256' => hash('sha256', json_encode($replayedParts, JSON_THROW_ON_ERROR))],
        'invariants' => ['collections_ready' => 2, 'binary_aggregate_rows' => count($replayState['binaries']),
            'no_orphans' => true, 'replay_did_not_duplicate_parts' => true],
    ];
} finally {
    Carbon::setTestNow();
    try {
        if ($createdDatabase) {
            config(['database.connections.mysql.database' => 'information_schema']);
            DB::purge('mysql');
            DB::reconnect('mysql');
            DB::statement("DROP DATABASE IF EXISTS `{$dbName}`");
        }
    } finally {
        foreach ([$markerPath, $markerPath.'.lock', $markerPath.'.recovery'] as $path) {
            if (is_file($path)) {
                @unlink($path);
            }
        }
        if (is_dir($markerDirectory)) {
            @rmdir($markerDirectory);
        }
    }
}

echo json_encode($result, JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR).PHP_EOL;
